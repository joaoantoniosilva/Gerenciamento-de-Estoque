package Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Entidades.Pedido;
import Repositorios.PedidoRepository;

@Service
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    // Métodos de serviço para operações relacionadas a pedidos

    public Pedido criarPedido(Pedido pedido) {
        return pedidoRepository.save(pedido);
    }

    public List<Pedido> listarPedidos() {
        return pedidoRepository.findAll();
    }

    public Pedido buscarPedidoPorId(Long pedidoId) {
        return pedidoRepository.findById(pedidoId).orElse(null);
    }

    public List<Pedido> listarPedidosPorCliente(Long clienteId) {
        return pedidoRepository.findByClienteId(clienteId);
    }

    public Pedido atualizarStatusPedido(Long pedidoId, ch.qos.logback.core.status.Status statusPedido) {
        Pedido pedido = buscarPedidoPorId(pedidoId);
        if (pedido != null) {
            pedido.setStatus(statusPedido);
            return pedidoRepository.save(pedido);
        }
        return null;
    }

}